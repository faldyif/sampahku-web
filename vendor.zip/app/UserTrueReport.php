<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTrueReport extends Model
{
    //
}
