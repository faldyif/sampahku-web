<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class point_history extends Model
{
    //
}
