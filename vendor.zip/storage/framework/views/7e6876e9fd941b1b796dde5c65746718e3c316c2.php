<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">

  <p>  Hai Admin </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>