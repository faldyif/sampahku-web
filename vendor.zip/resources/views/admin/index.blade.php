@extends('layouts.admin')

@section('title', 'Admin')

@section('content')
<div id="page-wrapper">

  <p>  Hai Admin </p>
</div>
@endsection
